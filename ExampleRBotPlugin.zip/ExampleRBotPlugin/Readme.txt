﻿
Make sure you reference RBot.exe in *References*